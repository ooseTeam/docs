﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using Assets;

public class GameWorldController : MonoBehaviour {
	public StaticMap StaticMap = new StaticMap();
	public DynamicMap DynamicMap = new DynamicMap();

	public GameObject WallPrefab;
	public GameObject EntityPrefab;

	public JoystickLogic PlayerController;
	public CameraFollower CameraController;
	public SightUpdater Sight;

	public void Start() {
		StaticMap.Walls = new List<Wall>();
		DynamicMap.Entities = new List<Entity>();
		DynamicMap.PowerUps = new List<PowerUp>();

		for (int i = 0; i < 10; ++i) {
			Wall w = new Wall(
				WallPrefab,
				new Vector2(Random.Range(0.0f, 20.0f), Random.Range(0.0f, 20.0f)),
				new Vector2(Random.Range(0.0f, 20.0f), Random.Range(0.0f, 20.0f))
			);
			StaticMap.Walls.Add(w);
		}

		Entity et = Entity.Create<PlayerControl>(EntityPrefab);
		((PlayerControl)et.Binding.Logic).BoundJoystick = PlayerController;
		((PlayerControl)et.Binding.Logic).Sight = Sight;
		CameraController.FollowingCharacter = et;
		DynamicMap.Entities.Add(et);
	}

	public Vector2 GetNearestPointToSegment(Vector2 segp1, Vector2 segp2, Vector2 pt) {
		Vector2 d12 = segp2 - segp1;
		float c1v = Vector2.Dot(d12, pt - segp1), c2v = Vector2.Dot(d12, pt - segp2);
		if (c1v * c2v < 0.0) {
			return segp1 + d12 * (c1v / (c1v - c2v));
		}
		return (c1v < 0.0 ? segp1 : segp2);
	}

	public void Update() { // check for collisions
		foreach (Entity ent in DynamicMap.Entities) {
			float walldissq = ent.Diameter + WallController.WallWidth;
			walldissq *= walldissq * 0.25f;
			foreach (Wall w in StaticMap.Walls) {
				Vector2 nearp = GetNearestPointToSegment(w.Node1, w.Node2, ent.Position), dnp = ent.Position - nearp;
				float dnplsq = dnp.sqrMagnitude;
				if (dnplsq < walldissq) {
					ent.Position = nearp + dnp * Mathf.Sqrt(walldissq / dnplsq);
				}
			}
		}
	}
}
