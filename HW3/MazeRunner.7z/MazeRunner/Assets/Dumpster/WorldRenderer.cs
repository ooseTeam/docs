﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.Rendering;
using Assets;

public class WorldRenderer : MonoBehaviour {
	public GameWorldController World;

	public Mesh Team1Mesh, Team2Mesh;
	public Material RenderMaterial;

	private Mesh _terrainMesh, _terrainShadowMesh;
	private CommandBuffer _renderCmd = null;

	public void OnRenderImage(RenderTexture source, RenderTexture destination) {
		Graphics.SetRenderTarget(destination);
		Graphics.ExecuteCommandBuffer(_renderCmd);
	}

	const float WallWidth = 0.2f, WallHeight = 2.0f;

	private static void AddQuad(Vector3 p1, Vector3 p2, Vector3 p3, Vector3 p4, Color clr, List<Vector3> vxs, List<int> ids, List<Color> clrs, List<Vector3> ns) {
		int c = vxs.Count;
		Vector3 normal = Vector3.Cross(p1 - p2, p3 - p2).normalized;
		vxs.Add(p1);
		clrs.Add(clr);
		ns.Add(normal);
		vxs.Add(p2);
		clrs.Add(clr);
		ns.Add(normal);
		vxs.Add(p3);
		clrs.Add(clr);
		ns.Add(normal);
		vxs.Add(p4);
		clrs.Add(clr);
		ns.Add(normal);
		ids.Add(c + 0);
		ids.Add(c + 1);
		ids.Add(c + 2);
		ids.Add(c + 0);
		ids.Add(c + 2);
		ids.Add(c + 3);
	}
	private static Mesh GenerateTerrainMesh(GameWorldController world) {
		List<Vector3> vertices = new List<Vector3>();
		List<int> indices = new List<int>();
		List<Color> colors = new List<Color>();
		List<Vector3> normals = new List<Vector3>();
		AddQuad(
			new Vector3(-100.0f, 0.0f, 100.0f), new Vector3(100.0f, 0.0f, 100.0f),
			new Vector3(100.0f, 0.0f, -100.0f), new Vector3(-100.0f, 0.0f, -100.0f),
			new Color(0.0f, 1.0f, 0.1f, 1.0f), vertices, indices, colors, normals
		);
		foreach (Wall w in world.StaticMap.Walls) {
			Vector2 diff12 = w.Node2 - w.Node1;
			diff12 = new Vector2(-diff12.y, diff12.x).normalized * (0.5f * WallWidth);
			Vector2 ptl = w.Node2 + diff12, ptr = w.Node2 - diff12, pbl = w.Node1 + diff12, pbr = w.Node1 - diff12;
			AddQuad(
				new Vector3(ptl.x, 0.0f, ptl.y), new Vector3(ptl.x, WallHeight, ptl.y),
				new Vector3(pbl.x, WallHeight, pbl.y), new Vector3(pbl.x, 0.0f, pbl.y),
				new Color(0.4f, 0.4f, 0.4f, 1.0f), vertices, indices, colors, normals
			);
			AddQuad(
				new Vector3(pbl.x, 0.0f, pbl.y), new Vector3(pbl.x, WallHeight, pbl.y),
				new Vector3(pbr.x, WallHeight, pbr.y), new Vector3(pbr.x, 0.0f, pbr.y),
				new Color(0.4f, 0.4f, 0.4f, 1.0f), vertices, indices, colors, normals
			);
			AddQuad(
				new Vector3(pbr.x, 0.0f, pbr.y), new Vector3(pbr.x, WallHeight, pbr.y),
				new Vector3(ptr.x, WallHeight, ptr.y), new Vector3(ptr.x, 0.0f, ptr.y),
				new Color(0.4f, 0.4f, 0.4f, 1.0f), vertices, indices, colors, normals
			);
			AddQuad(
				new Vector3(ptr.x, 0.0f, ptr.y), new Vector3(ptr.x, WallHeight, ptr.y),
				new Vector3(ptl.x, WallHeight, ptl.y), new Vector3(ptl.x, 0.0f, ptl.y),
				new Color(0.4f, 0.4f, 0.4f, 1.0f), vertices, indices, colors, normals
			);
			AddQuad(
				new Vector3(ptl.x, WallHeight, ptl.y), new Vector3(ptr.x, WallHeight, ptr.y),
				new Vector3(pbr.x, WallHeight, pbr.y), new Vector3(pbl.x, WallHeight, pbl.y),
				new Color(0.4f, 0.4f, 0.4f, 1.0f), vertices, indices, colors, normals
			);
		}
		Mesh m = new Mesh();
		m.vertices = vertices.ToArray();
		m.triangles = indices.ToArray();
		m.colors = colors.ToArray();
		m.normals = normals.ToArray();
		return m;
	}

	private void Start() {
		_terrainMesh = GenerateTerrainMesh(World);

		_renderCmd = new CommandBuffer();
		_renderCmd.ClearRenderTarget(true, true, Color.black);
		_renderCmd.DrawMesh(_terrainMesh, Matrix4x4.identity, RenderMaterial);
	}
}
