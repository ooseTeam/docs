﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using Assets;

public class CameraFollower : MonoBehaviour {
	public Entity FollowingCharacter;

	private Transform _cam;

	void Start() {
		_cam = GetComponent<Transform>();
	}

	void Update() {
		_cam.position = new Vector3(FollowingCharacter.Position.x, 6.0f, FollowingCharacter.Position.y - 8.0f);
		_cam.LookAt(new Vector3(FollowingCharacter.Position.x, 0.0f, FollowingCharacter.Position.y));
	}
}
