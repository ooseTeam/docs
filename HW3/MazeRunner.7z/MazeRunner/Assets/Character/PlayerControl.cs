﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using Assets;
using System;

public class PlayerControl : MonoBehaviour, IEntityControl {
	public JoystickLogic BoundJoystick;
	public SightUpdater Sight;

	public struct MoveSpeedStep {
		public MoveSpeedStep(float l, float ts) {
			Length = l;
			TargetSpeed = ts;
		}

		public float Length, TargetSpeed;
	}
	public static readonly MoveSpeedStep[] SpeedSteps = {
		new MoveSpeedStep(20.0f, 3.0f),
		new MoveSpeedStep(10.0f, 1.0f)
	};

	private FundamentalControl _fund;

	private void Start() {
		_fund = GetComponent<FundamentalControl>();
	}

	public void OnAffectedByPowerUp(PowerUp powerup) {
	}
	public void OnHearNoise() {
	}

	private void Update() {
		if (BoundJoystick.HasValue) {
			Vector2 offset = BoundJoystick.Offset;
			float len = offset.magnitude;
			foreach (MoveSpeedStep step in SpeedSteps) {
				if (len > step.Length) {
					offset *= step.TargetSpeed / len;
					_fund.Target.Position += offset * Time.deltaTime; 
					break;
				}
			}
		}
		Sight.Position = _fund.Target.Position;
	}
}
