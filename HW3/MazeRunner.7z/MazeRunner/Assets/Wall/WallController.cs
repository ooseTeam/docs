﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using Assets;

public class WallController : MonoBehaviour {
	public Vector2 Node1, Node2;

	public const float WallHeight = 2.0f * Parameters.SceneScale, WallWidth = 0.2f * Parameters.SceneScale;
	private readonly Vector3 _wallLift = new Vector3(0.0f, 0.5f * WallHeight, 0.0f);

	private Mesh _mesh;

	private void AppendQuad(Vector3 center, Vector3 extx, Vector3 exty, List<Vector3> vxs, List<int> ids) {
		int idb = vxs.Count;
		vxs.Add(center - extx + exty);
		vxs.Add(center + extx + exty);
		vxs.Add(center + extx - exty);
		vxs.Add(center - extx - exty);
		ids.Add(idb + 0);
		ids.Add(idb + 1);
		ids.Add(idb + 2);
		ids.Add(idb + 0);
		ids.Add(idb + 2);
		ids.Add(idb + 3);
	}

	private void Start() {
		_mesh = new Mesh();
		GetComponent<MeshFilter>().mesh = _mesh;
		ResetMesh();
	}
	public void ResetMesh() {
		List<Vector3> vxs = new List<Vector3>();
		List<int> ids = new List<int>();
		Vector2
			p12 = (Node2 - Node1) * 0.5f,
			pprp = p12.RotatedLeft90().normalized * (0.5f * WallWidth),
			pmid = 0.5f * (Node1 + Node2);
		Vector3
			p12v = p12.OntoGround(),
			pprpv = pprp.OntoGround(),
			pmidv = new Vector3(pmid.x, 0.5f * WallHeight, pmid.y);
		AppendQuad(pmidv + pprpv, -p12v, _wallLift, vxs, ids);
		AppendQuad(pmidv + p12v, pprpv, _wallLift, vxs, ids);
		AppendQuad(pmidv - pprpv, p12v, _wallLift, vxs, ids);
		AppendQuad(pmidv - p12v, -pprpv, _wallLift, vxs, ids);
		AppendQuad(pmidv + _wallLift, p12v, pprpv, vxs, ids);
		_mesh.vertices = vxs.ToArray();
		_mesh.triangles = ids.ToArray();
		_mesh.RecalculateNormals();
	}
}
