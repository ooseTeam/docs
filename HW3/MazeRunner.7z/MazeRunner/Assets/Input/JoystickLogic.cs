﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.EventSystems;

public class JoystickLogic : MonoBehaviour {
	public Texture FromTexture, CurrentTexture;

	public Vector2 Offset {
		get {
			return CurrentPosition - StartingPosition;
		}
	}
	public Vector2 CurrentPosition {
		get;
		private set;
	}
	public Vector2 StartingPosition {
		get;
		private set;
	}
	public bool HasValue {
		get;
		private set;
	}

	private int _activeTouch;
	private RectTransform _layout;

	private static Rect GetRect(Vector2 pos, float size = 20.0f) {
		return new Rect(pos.x - size * 0.5f, pos.y - size * 0.5f, size, size);
	}
	private Vector2 WorldToClient(Vector2 pos) {
		return new Vector2(pos.x / _layout.lossyScale.x, pos.y / _layout.lossyScale.y);
	}
	private Vector2 ClientToWorld(Vector2 pos) {
		return new Vector2(pos.x * _layout.lossyScale.x, pos.y * _layout.lossyScale.y);
	}

	private void Start() {
		_layout = GetComponent<RectTransform>();
	}
	private void OnGUI() {
		GL.PushMatrix();
		GL.LoadPixelMatrix();

		if (HasValue) {
			Graphics.DrawTexture(GetRect(ClientToWorld(StartingPosition), 20.0f * _layout.lossyScale.x), FromTexture);
			Graphics.DrawTexture(GetRect(ClientToWorld(CurrentPosition), 20.0f * _layout.lossyScale.x), CurrentTexture);
		}

		GL.PopMatrix();
	}
	private void Update() {
		if (HasValue) {
			HasValue = false;
			foreach (Touch t in Input.touches) {
				if (t.fingerId == _activeTouch) {
					HasValue = true;
					CurrentPosition = WorldToClient(t.position);
				}
			}
		} else {
			foreach (Touch t in Input.touches) {
				if (t.phase == TouchPhase.Began && _layout.rect.Contains(WorldToClient(t.position))) {
					HasValue = true;
					StartingPosition = CurrentPosition = WorldToClient(t.position);
					_activeTouch = t.fingerId;
				}
			}
		}
#if UNITY_EDITOR
		StartingPosition = new Vector2();
		CurrentPosition = 30.0f * new Vector2(Input.GetAxis("Horizontal"), Input.GetAxis("Vertical"));
		if (Offset.magnitude > 1e-6) {
			HasValue = true;
		}
#endif
	}
}
