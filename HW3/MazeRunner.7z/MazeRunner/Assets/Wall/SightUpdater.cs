﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using Assets;

public class SightUpdater : MonoBehaviour {
	public GameWorldController GameWorld;
	public bool IsEnabled;
	public Vector2 Position;

	private Mesh _mesh;

	private void Start() {
		_mesh = GetComponent<MeshFilter>().mesh;
	}

	private void AddSegment(Vector2 p1, Vector2 p2, List<Vector3> vxs, List<int> ids) {
		Vector2 d12 = (p2 - p1).RotatedRight90(), dp1 = p1 - Position;
		if (Vector2.Dot(d12, dp1) > 0.0) {
			int id = vxs.Count;
			Vector2 dp2 = p2 - Position;
			vxs.Add(p1.OntoGround());
			vxs.Add(p2.OntoGround());
			vxs.Add((p2 + dp2 * 1000.0f).OntoGround());
			vxs.Add((p1 + dp1 * 1000.0f).OntoGround());
			ids.Add(id + 0);
			ids.Add(id + 1);
			ids.Add(id + 2);
			ids.Add(id + 0);
			ids.Add(id + 2);
			ids.Add(id + 3);
		}
	}
	private void Update() {
		if (IsEnabled) {
			List<Vector3> vertices = new List<Vector3>();
			List<int> indices = new List<int>();
			foreach (Wall w in GameWorld.StaticMap.Walls) {
				Vector2
					p12p = (w.Node2 - w.Node1).RotatedLeft90().normalized * (0.5f * WallController.WallWidth),
					ptl = w.Node2 + p12p, ptr = w.Node2 - p12p,
					pbl = w.Node1 + p12p, pbr = w.Node1 - p12p;
				AddSegment(ptl, pbl, vertices, indices);
				AddSegment(pbl, pbr, vertices, indices);
				AddSegment(pbr, ptr, vertices, indices);
				AddSegment(ptr, ptl, vertices, indices);
			}
			_mesh.Clear();
			_mesh.SetVertices(vertices);
			_mesh.SetTriangles(indices, 0);
		}
	}
}
