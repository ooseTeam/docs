﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using Assets;

public class FundamentalControl : MonoBehaviour {
	public Entity Target;

	private Transform _trans;
	private void Start() {
		_trans = GetComponent<Transform>();
	}
	private void Update () {
		_trans.localScale = new Vector3(Target.Diameter, 1.0f, Target.Diameter);
		_trans.position = new Vector3(Target.Position.x, 0.0f, Target.Position.y);
	}
}
