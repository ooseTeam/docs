﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class FPSViewer : MonoBehaviour {
	private int _fps, _cntr;
	private int _time;

	void Update() {
		int newt = (int)Mathf.Floor(Time.realtimeSinceStartup);
		if (_time < newt) {
			_fps = _cntr;
			_cntr = 0;
			_time = newt;
		}
		++_cntr;
	}

	private void OnGUI() {
		GUILayout.Label("<color=#000000FF>FPS: " + _fps.ToString() + "</color>");
	}
}
