﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using UnityEngine;
using UnityEngine.Rendering;

namespace Assets {
	public static class Parameters {
		public const float SceneScale = 1.0f;
	}

	public static class Utils {
		public static Vector2 RotatedLeft90(this Vector2 vec) {
			return new Vector2(-vec.y, vec.x);
		}
		public static Vector2 RotatedRight90(this Vector2 vec) {
			return new Vector2(vec.y, -vec.x);
		}
		public static float Cross(this Vector2 lhs, Vector2 rhs) {
			return lhs.x * rhs.y - lhs.y * rhs.x;
		}

		public static Vector3 OntoGround(this Vector2 vec) {
			return new Vector3(vec.x, 0.0f, vec.y);
		}
	}

	public struct SceneBinding<T> {
		public SceneBinding(GameObject obj) {
			Object = obj;
			Logic = Object.GetComponent<T>();
		}

		public GameObject Object;
		public T Logic;
	}

	public interface IEntityControl {
		void OnHearNoise();
		void OnAffectedByPowerUp(PowerUp powerup);
	}
	public enum EntityType {
		Player,
		Enemy,
		Teammate
	}
	public class Entity {
		public EntityType Type;
		public Vector2 Position;
		public float Diameter = 0.6f;

		public PowerUp CarryingPowerUp;

		public SceneBinding<IEntityControl> Binding;

		public static Entity Create<T>(GameObject prefab) where T : MonoBehaviour, IEntityControl {
			Entity et = new Entity();
			et.Binding.Object = UnityEngine.Object.Instantiate(prefab);
			et.Binding.Logic = et.Binding.Object.AddComponent<T>();
			et.Binding.Object.GetComponent<FundamentalControl>().Target = et;
			return et;
		}
	}

	public class PowerUp {
		public Vector2 Position;
	}

	public struct Wall {
		public Wall(GameObject prefab, Vector2 p1, Vector2 p2) {
			Binding = new SceneBinding<WallController>(UnityEngine.Object.Instantiate(prefab));
			Binding.Logic.Node1 = p1;
			Binding.Logic.Node2 = p2;
		}

		public Vector2 Node1 {
			get {
				return Binding.Logic.Node1;
			}
		}
		public Vector2 Node2 {
			get {
				return Binding.Logic.Node2;
			}
		}

		SceneBinding<WallController> Binding;
	}

	public struct StaticMap {
		public List<Wall> Walls;
	}
	public struct DynamicMap {
		public List<Entity> Entities;
		public List<PowerUp> PowerUps;
	}
}
